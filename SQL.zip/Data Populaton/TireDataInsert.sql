/*
INSERT INTO TIRES (Tire_partNum, Width, Diameter, Construction, Pressure, Type_Tires) VALUES ('CP641', 205, 15, 'R', 30, 'All Season');
INSERT INTO TIRES (Tire_partNum, Width, Diameter, Construction, Pressure, Type_Tires) VALUES ('ZE950', 195, 15, 'R', 51, 'All Season');
INSERT INTO TIRES (Tire_partNum, Width, Diameter, Construction, Pressure, Type_Tires) VALUES ('101YXLBSW', 255, 20, 'R', 32, 'All Season');
INSERT INTO TIRES (Tire_partNum, Width, Diameter, Construction, Pressure, Type_Tires) VALUES ('FK450', 225, 18, 'R', 33, 'All Season');
INSERT INTO TIRES (Tire_partNum, Width, Diameter, Construction, Pressure, Type_Tires) VALUES ('SN201', 215, 15, 'R', 30, 'All Season');
INSERT INTO TIRES (Tire_partNum, Width, Diameter, Construction, Pressure, Type_Tires) VALUES ('LX25', 255, 19, 'R', 35, 'All Season');
INSERT INTO TIRES (Tire_partNum, Width, Diameter, Construction, Pressure, Type_Tires) VALUES ('DZ102', 245, 18, 'R', 38, 'All Season');
INSERT INTO TIRES (Tire_partNum, Width, Diameter, Construction, Pressure, Type_Tires) VALUES ('3HM', 185, 16, 'R', 33, 'All Season');
INSERT INTO TIRES (Tire_partNum, Width, Diameter, Construction, Pressure, Type_Tires) VALUES ('PA31', 225, 17, 'R', 32, 'All Season');
INSERT INTO TIRES (Tire_partNum, Width, Diameter, Construction, Pressure, Type_Tires) VALUES ('LS-2', 235, 18, 'R', 35, 'All Season');
INSERT INTO TIRES (Tire_partNum, Width, Diameter, Construction, Pressure, Type_Tires) VALUES ('AH5', 215, 16, 'R', 35, 'All Season');
INSERT INTO TIRES (Tire_partNum, Width, Diameter, Construction, Pressure, Type_Tires) VALUES ('SJ8', 245, 18, 'R', 35, 'Winter');
INSERT INTO TIRES (Tire_partNum, Width, Diameter, Construction, Pressure, Type_Tires) VALUES ('SR-A', 235, 16, 'R', 32, 'All Season');
INSERT INTO TIRES (Tire_partNum, Width, Diameter, Construction, Pressure, Type_Tires) VALUES ('NT90W', 235, 17, 'R', 34, 'Winter');
INSERT INTO TIRES (Tire_partNum, Width, Diameter, Construction, Pressure, Type_Tires) VALUES ('LE3', 225, 16, 'R', 33, 'All Season');
INSERT INTO TIRES (Tire_partNum, Width, Diameter, Construction, Pressure, Type_Tires) VALUES ('PS890', 235, 16, 'R', 35, 'All Season');
INSERT INTO TIRES (Tire_partNum, Width, Diameter, Construction, Pressure, Type_Tires) VALUES ('LH-503', 225, 17, 'R', 33, 'All Season');
INSERT INTO TIRES (Tire_partNum, Width, Diameter, Construction, Pressure, Type_Tires) VALUES ('DSW-06', 215, 17, 'R', 33, 'All Season');
INSERT INTO TIRES (Tire_partNum, Width, Diameter, Construction, Pressure, Type_Tires) VALUES ('A/S', 215, 17, 'R', 34, 'All Season');
INSERT INTO TIRES (Tire_partNum, Width, Diameter, Construction, Pressure, Type_Tires) VALUES ('T/A LT', 235, 18, 'R', 36, 'All Season');
INSERT INTO TIRES (Tire_partNum, Width, Diameter, Construction, Pressure, Type_Tires) VALUES ('LTX', 275, 20, 'R', 35, 'All Season');
INSERT INTO TIRES (Tire_partNum, Width, Diameter, Construction, Pressure, Type_Tires) VALUES ('DWS', 225, 16, 'R', 33, 'All Season');
INSERT INTO TIRES (Tire_partNum, Width, Diameter, Construction, Pressure, Type_Tires) VALUES ('PS830', 185, 14, 'R', 32, 'All Season');
INSERT INTO TIRES (Tire_partNum, Width, Diameter, Construction, Pressure, Type_Tires) VALUES ('GLX', 205, 16, 'R', 33, 'All Season');
*/
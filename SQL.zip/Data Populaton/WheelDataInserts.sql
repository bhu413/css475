/*
INSERT INTO WHEELS (Rim_size, Wheel_partNum, Tire_partNum) VALUES (15, '5899-04030988', 'CP641');
INSERT INTO WHEELS (Rim_size, Wheel_partNum, Tire_partNum) VALUES (15, 'ALY58707U20', 'ZE950');
INSERT INTO WHEELS (Rim_size, Wheel_partNum, Tire_partNum) VALUES (20, 'OW62569', '101YXLBSW');
INSERT INTO WHEELS (Rim_size, Wheel_partNum, Tire_partNum) VALUES (18, 'ALY70873', 'FK450');
INSERT INTO WHEELS (Rim_size, Wheel_partNum, Tire_partNum) VALUES (15, '42601AD020', 'SN201');
INSERT INTO WHEELS (Rim_size, Wheel_partNum, Tire_partNum) VALUES (19, '36116858874', 'LX25');
INSERT INTO WHEELS (Rim_size, Wheel_partNum, Tire_partNum) VALUES (18, '8T0601025A', 'DZ102');
INSERT INTO WHEELS (Rim_size, Wheel_partNum, Tire_partNum) VALUES (16, 'T5A16060A', '3HM');
INSERT INTO WHEELS (Rim_size, Wheel_partNum, Tire_partNum) VALUES (17, '129944-04165200', 'PA31');
INSERT INTO WHEELS (Rim_size, Wheel_partNum, Tire_partNum) VALUES (18, '1564011300', 'LS-2');
INSERT INTO WHEELS (Rim_size, Wheel_partNum, Tire_partNum) VALUES (16, '5N0601025R8Z8', 'AH5');
INSERT INTO WHEELS (Rim_size, Wheel_partNum, Tire_partNum) VALUES (18, 'FT4C1007A1A', 'SJ8');
INSERT INTO WHEELS (Rim_size, Wheel_partNum, Tire_partNum) VALUES (16, '1L2Z1007HA', 'SR-A');
INSERT INTO WHEELS (Rim_size, Wheel_partNum, Tire_partNum) VALUES (17, '36113401200', 'NT90W');
INSERT INTO WHEELS (Rim_size, Wheel_partNum, Tire_partNum) VALUES (16, '5EZ98TAEAB', 'LE3');
INSERT INTO WHEELS (Rim_size, Wheel_partNum, Tire_partNum) VALUES (16, '42700SHJA01', 'PS890');
INSERT INTO WHEELS (Rim_size, Wheel_partNum, Tire_partNum) VALUES (17, '8P0601025AF', 'LH-503');
INSERT INTO WHEELS (Rim_size, Wheel_partNum, Tire_partNum) VALUES (17, '9965617070', 'DSW-06');
INSERT INTO WHEELS (Rim_size, Wheel_partNum, Tire_partNum) VALUES (17, '1LT46TRMAA', 'A/S');
INSERT INTO WHEELS (Rim_size, Wheel_partNum, Tire_partNum) VALUES (18, '18075D', 'T/A LT');
INSERT INTO WHEELS (Rim_size, Wheel_partNum, Tire_partNum) VALUES (20, '20937765', 'LTX');
INSERT INTO WHEELS (Rim_size, Wheel_partNum, Tire_partNum) VALUES (16, 'A99', 'DWS');
INSERT INTO WHEELS (Rim_size, Wheel_partNum, Tire_partNum) VALUES (14, '4261102140', 'PS830');
INSERT INTO WHEELS (Rim_size, Wheel_partNum, Tire_partNum) VALUES (16, '3B0601025T8Z8', 'GLX');
*/
/*
INSERT INTO ENGINE (Engine_modelNum, Oil, Fuel, Cylinder, Displacement, Spark_partNum) VALUES ('G25A4', '10W-30', 'unleaded', 5, 2.5, '92145');
INSERT INTO ENGINE (Engine_modelNum, Oil, Fuel, Cylinder, Displacement, Spark_partNum) VALUES ('C4', '10W-30', 'unleaded', 6, 2.8, '9607');
INSERT INTO ENGINE (Engine_modelNum, Oil, Fuel, Cylinder, Displacement, Spark_partNum) VALUES ('VR38DETT', '5W-40', 'premium ', 6, 3.8, '93026');
INSERT INTO ENGINE (Engine_modelNum, Oil, Fuel, Cylinder, Displacement, Spark_partNum) VALUES ('Lambda GDI', '5W-30', 'unleaded', 6, 3.8, '92145');
INSERT INTO ENGINE (Engine_modelNum, Oil, Fuel, Cylinder, Displacement, Spark_partNum) VALUES ('2TR-FE', '5W-30', 'unleaded', 4, 2.7, '92145');
INSERT INTO ENGINE (Engine_modelNum, Oil, Fuel, Cylinder, Displacement, Spark_partNum) VALUES ('N55B30M0', '5W-30', 'premium', 6, 3.0, '97506');
INSERT INTO ENGINE (Engine_modelNum, Oil, Fuel, Cylinder, Displacement, Spark_partNum) VALUES ('CAKA, CCBA', '5W-30', 'premium', 6, 3.0, 'XP3923');
INSERT INTO ENGINE (Engine_modelNum, Oil, Fuel, Cylinder, Displacement, Spark_partNum) VALUES ('L12B i-VTEC', '0W-20', 'unleaded', 4, 1.5, '92145');
INSERT INTO ENGINE (Engine_modelNum, Oil, Fuel, Cylinder, Displacement, Spark_partNum) VALUES ('H4 EJ25', '5W-30', 'unleaded', 4, 2.5, '92145');
INSERT INTO ENGINE (Engine_modelNum, Oil, Fuel, Cylinder, Displacement, Spark_partNum) VALUES ('M270', '0W-40', 'premium', 4, 2.0, '90654');
INSERT INTO ENGINE (Engine_modelNum, Oil, Fuel, Cylinder, Displacement, Spark_partNum) VALUES ('ENG-67961', '5W-40', 'premium', 4, 2.0, 'XP3923');
INSERT INTO ENGINE (Engine_modelNum, Oil, Fuel, Cylinder, Displacement, Spark_partNum) VALUES ('819-011', '5W-30', 'premium', 4, 2.0, '9616');
INSERT INTO ENGINE (Engine_modelNum, Oil, Fuel, Cylinder, Displacement, Spark_partNum) VALUES ('JA8Z6006B', '5W-20', 'unleaded', 6, 4.0, '9660');
INSERT INTO ENGINE (Engine_modelNum, Oil, Fuel, Cylinder, Displacement, Spark_partNum) VALUES ('C242869936G', '5W-30', 'premium ', 6, 3.0, 'XP5325');
INSERT INTO ENGINE (Engine_modelNum, Oil, Fuel, Cylinder, Displacement, Spark_partNum) VALUES ('R8272107AA', '10W-30', 'unleaded ', 6, 4.0, '9656');
INSERT INTO ENGINE (Engine_modelNum, Oil, Fuel, Cylinder, Displacement, Spark_partNum) VALUES ('3471CC', '5W-20', 'unleaded', 6, 3.5, '9604');
INSERT INTO ENGINE (Engine_modelNum, Oil, Fuel, Cylinder, Displacement, Spark_partNum) VALUES ('R19647', '5W-40', 'premium', 4, 2.0, 'XP5325');
INSERT INTO ENGINE (Engine_modelNum, Oil, Fuel, Cylinder, Displacement, Spark_partNum) VALUES ('SkyActiv-G PE-VPS', '0W-20', 'unleaded', 4, 2.0, '9621');
INSERT INTO ENGINE (Engine_modelNum, Oil, Fuel, Cylinder, Displacement, Spark_partNum) VALUES ('68253324AB', '5W-20', 'unleaded', 4, 2.4, '9651');
INSERT INTO ENGINE (Engine_modelNum, Oil, Fuel, Cylinder, Displacement, Spark_partNum) VALUES ('R17462', '0W-20', 'premium', 6, 3.5, '9619');
INSERT INTO ENGINE (Engine_modelNum, Oil, Fuel, Cylinder, Displacement, Spark_partNum) VALUES ('UPC238554670I', '0W-20', 'unleaded/flex', 8, 5.3, '96307');
INSERT INTO ENGINE (Engine_modelNum, Oil, Fuel, Cylinder, Displacement, Spark_partNum) VALUES ('EJ205', '5W-30', 'premium', 4, 2.0, 'FR7NI33');
INSERT INTO ENGINE (Engine_modelNum, Oil, Fuel, Cylinder, Displacement, Spark_partNum) VALUES ('300-65119B', '5W-30', 'unleaded', 4, 1.8, '9600');
INSERT INTO ENGINE (Engine_modelNum, Oil, Fuel, Cylinder, Displacement, Spark_partNum) VALUES ('1781CC', '5W-40', 'premium', 4, 1.8, '9610');
*/
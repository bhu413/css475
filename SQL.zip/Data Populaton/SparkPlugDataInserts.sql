/*
INSERT INTO SPARK_PLUG (Spark_partNum, Seat_style, Thread_size, Drive_size) VALUES ('IZFR6K11', 'Gasket', 14, 0.625);
INSERT INTO SPARK_PLUG (Spark_partNum, Seat_style, Thread_size, Drive_size) VALUES ('9600', 'Gasket', 19, 16);
INSERT INTO SPARK_PLUG (Spark_partNum, Seat_style, Thread_size, Drive_size) VALUES ('92145', 'Gasket', 14, 0.625);
INSERT INTO SPARK_PLUG (Spark_partNum, Seat_style, Thread_size, Drive_size) VALUES ('9607', 'Gasket', 14, 16);
INSERT INTO SPARK_PLUG (Spark_partNum, Seat_style, Thread_size, Drive_size) VALUES ('93026', 'Gasket', 12, 14);
INSERT INTO SPARK_PLUG (Spark_partNum, Seat_style, Thread_size, Drive_size) VALUES ('97506', 'Gasket', 26, 14);
INSERT INTO SPARK_PLUG (Spark_partNum, Seat_style, Thread_size, Drive_size) VALUES ('XP3923', 'Gasket', 14, 0.625);
INSERT INTO SPARK_PLUG (Spark_partNum, Seat_style, Thread_size, Drive_size) VALUES ('90654', 'Gasket', 12, 14);
INSERT INTO SPARK_PLUG (Spark_partNum, Seat_style, Thread_size, Drive_size) VALUES ('9616', 'Tapered', 14, 16);
INSERT INTO SPARK_PLUG (Spark_partNum, Seat_style, Thread_size, Drive_size) VALUES ('9660', 'Tapered', 17, 16);
INSERT INTO SPARK_PLUG (Spark_partNum, Seat_style, Thread_size, Drive_size) VALUES ('XP5325', 'Gasket', 14, 0.625);
INSERT INTO SPARK_PLUG (Spark_partNum, Seat_style, Thread_size, Drive_size) VALUES ('9656', 'Gasket', 19, 16);
INSERT INTO SPARK_PLUG (Spark_partNum, Seat_style, Thread_size, Drive_size) VALUES ('9604', 'Flat', 14, 16);
INSERT INTO SPARK_PLUG (Spark_partNum, Seat_style, Thread_size, Drive_size) VALUES ('9621', 'Gasket', 26, 14);
INSERT INTO SPARK_PLUG (Spark_partNum, Seat_style, Thread_size, Drive_size) VALUES ('9651', 'Gasket', 19, 16);
INSERT INTO SPARK_PLUG (Spark_partNum, Seat_style, Thread_size, Drive_size) VALUES ('9619', 'Gasket', 26, 16);
INSERT INTO SPARK_PLUG (Spark_partNum, Seat_style, Thread_size, Drive_size) VALUES ('96307', 'Tapered', 14, 16);
INSERT INTO SPARK_PLUG (Spark_partNum, Seat_style, Thread_size, Drive_size) VALUES ('FR7NI33', 'Gasket', 26, 16);
INSERT INTO SPARK_PLUG (Spark_partNum, Seat_style, Thread_size, Drive_size) VALUES ('9610', 'Gasket', 19, 16);
*/
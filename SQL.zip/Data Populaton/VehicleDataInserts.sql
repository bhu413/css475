/*
INSERT INTO VEHICLE (Model_year, Make, Model, Engine_modelNum, Light_partNum, Wheel_partNum) VALUES (1995, 'Acura', 'TL', 'G25A4', 'AC2519102', '5899-04030988');
INSERT INTO VEHICLE (Model_year, Make, Model, Engine_modelNum, Light_partNum, Wheel_partNum) VALUES (1995, 'Audi', 'A6', 'C4', 'LH-9006', 'ALY58707U20');
INSERT INTO VEHICLE (Model_year, Make, Model, Engine_modelNum, Light_partNum, Wheel_partNum) VALUES (2015, 'Nissan', 'GT-R', 'VR38DETT', '26060-62B2A', 'OW62569');
INSERT INTO VEHICLE (Model_year, Make, Model, Engine_modelNum, Light_partNum, Wheel_partNum) VALUES (2015, 'Hyundai', 'Genesis', 'Lambda GDI', '1864755007S', 'ALY70873');
INSERT INTO VEHICLE (Model_year, Make, Model, Engine_modelNum, Light_partNum, Wheel_partNum) VALUES (2015, 'Toyota', 'Tacoma', '2TR-FE', '9007XV-2', '42601AD020');
INSERT INTO VEHICLE (Model_year, Make, Model, Engine_modelNum, Light_partNum, Wheel_partNum) VALUES (2015, 'BMW', 'X6', 'N55B30M0', 'D1SSZ', '36116858874');
INSERT INTO VEHICLE (Model_year, Make, Model, Engine_modelNum, Light_partNum, Wheel_partNum) VALUES (2015, 'Audi', 'S5', 'CAKA, CCBA', 'D3S', '8T0601025A');
INSERT INTO VEHICLE (Model_year, Make, Model, Engine_modelNum, Light_partNum, Wheel_partNum) VALUES (2015, 'Honda', 'Fit', 'L12B i-VTEC', '9003SU-2', 'T5A16060A');
INSERT INTO VEHICLE (Model_year, Make, Model, Engine_modelNum, Light_partNum, Wheel_partNum) VALUES (2015, 'Subaru', 'Legacy', 'H4 EJ25', 'H11SU-2', '129944-04165200');
INSERT INTO VEHICLE (Model_year, Make, Model, Engine_modelNum, Light_partNum, Wheel_partNum) VALUES (2015, 'Mercedes-Benz', 'GLA 250', 'M270', 'H7SU-2', '1564011300');
INSERT INTO VEHICLE (Model_year, Make, Model, Engine_modelNum, Light_partNum, Wheel_partNum) VALUES (2015, 'Volkswagen', 'Tiguan', 'ENG-67961', 'H7XV-2', '5N0601025R8Z8');
INSERT INTO VEHICLE (Model_year, Make, Model, Engine_modelNum, Light_partNum, Wheel_partNum) VALUES (2015, 'Ford', 'Edge', '819-011', '9005XV-2', 'FT4C1007A1A');
INSERT INTO VEHICLE (Model_year, Make, Model, Engine_modelNum, Light_partNum, Wheel_partNum) VALUES (2005, 'Ford', 'Explorer', 'JA8Z6006B', '9006XV-2', '1L2Z1007HA');
INSERT INTO VEHICLE (Model_year, Make, Model, Engine_modelNum, Light_partNum, Wheel_partNum) VALUES (2010, 'BMW', 'X3', 'C242869936G', 'H7XV-2', '36113401200');
INSERT INTO VEHICLE (Model_year, Make, Model, Engine_modelNum, Light_partNum, Wheel_partNum) VALUES (2000, 'Jeep', 'Grand Cherokee', 'R8272107AA', '9006XSSZ-2', '5EZ98TAEAB');
INSERT INTO VEHICLE (Model_year, Make, Model, Engine_modelNum, Light_partNum, Wheel_partNum) VALUES (2005, 'Honda', 'Odyssey', '3471CC', '9007XV', '42700SHJA01');
INSERT INTO VEHICLE (Model_year, Make, Model, Engine_modelNum, Light_partNum, Wheel_partNum) VALUES (2005, 'Audi', 'A3', 'R19647', 'H7XV-2', '8P0601025AF');
INSERT INTO VEHICLE (Model_year, Make, Model, Engine_modelNum, Light_partNum, Wheel_partNum) VALUES (2015, 'Mazda', 'CX-5', 'SkyActiv-G PE-VPS', 'H11XV-2', '9965617070');
INSERT INTO VEHICLE (Model_year, Make, Model, Engine_modelNum, Light_partNum, Wheel_partNum) VALUES (2015, 'Jeep', 'Compass', '68253324AB', '9012XV', '1LT46TRMAA');
INSERT INTO VEHICLE (Model_year, Make, Model, Engine_modelNum, Light_partNum, Wheel_partNum) VALUES (2015, 'Acura', 'RDX', 'R17462', '9005XV', '18075D');
INSERT INTO VEHICLE (Model_year, Make, Model, Engine_modelNum, Light_partNum, Wheel_partNum) VALUES (2015, 'Chevorlet', 'Tahoe', 'UPC238554670I', '9005XV-2', '20937765');
INSERT INTO VEHICLE (Model_year, Make, Model, Engine_modelNum, Light_partNum, Wheel_partNum) VALUES (2005, 'Subaru', 'WRX', 'EJ205', 'H1XV', 'A99');
INSERT INTO VEHICLE (Model_year, Make, Model, Engine_modelNum, Light_partNum, Wheel_partNum) VALUES (2000, 'Toyota', 'Corolla', '300-65119B', '9003XV-2', '4261102140');
INSERT INTO VEHICLE (Model_year, Make, Model, Engine_modelNum, Light_partNum, Wheel_partNum) VALUES (2000, 'Volkswagen', 'Passat', '1781CC', '9003XV-2', '3B0601025T8Z8');
*/
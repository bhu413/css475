CREATE TABLE SPARK_PLUG (
	Spark_partNum VARCHAR(30) NOT NULL,
	Drive_size FLOAT NOT NULL,
	Thread_size INT NOT NULL,
	Seat_style VARCHAR(30),
	PRIMARY KEY (Spark_partNum)
);
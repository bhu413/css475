CREATE TABLE TIRES (
	Tire_partNum VARCHAR(30) NOT NULL,
	Pressure INT NOT NULL,
	Construction VARCHAR(30),
	Diameter INT NOT NULL,
	Width INT NOT NULL,
	Type_Tires VARCHAR(30),
	PRIMARY KEY (Tire_partNum)
);